/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { Hero } from './components/sections/Hero';
import { Mission } from './components/sections/Mission';
import { Movement } from './components/sections/Movement';
import { ImpactDashboard } from './components/sections/ImpactDashboard';
import { StoryWall } from './components/sections/StoryWall';
import { KnowledgeHub } from './components/sections/KnowledgeHub';
import { Partnership } from './components/sections/Partnership';
import { WhyAnokhi } from './components/sections/WhyAnokhi';
import { Vision } from './components/sections/Vision';
import { Contact } from './components/sections/Contact';
import { WhatsAppButton } from './components/common/WhatsAppButton';
import { OrderButton } from './components/common/OrderButton';

export default function App() {
  return (
    <div className="min-h-screen bg-white font-sans text-anokhi-purple selection:bg-anokhi-green/20">
      <Navbar />
      <main>
        <Hero />
        <Mission />
        <Movement />
        <ImpactDashboard />
        <StoryWall />
        <WhyAnokhi />
        <KnowledgeHub />
        <Partnership />
        <Vision />
        <Contact />
      </main>
      <Footer />
      <WhatsAppButton />
      <OrderButton />
    </div>
  );
}
