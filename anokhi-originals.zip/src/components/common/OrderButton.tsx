import { motion } from 'motion/react';
import { ShoppingBag } from 'lucide-react';

export function OrderButton() {
  return (
    <motion.a
      href="#contact"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 1.2 }}
      className="fixed bottom-6 left-6 z-50 bg-anokhi-purple text-white px-6 py-3 md:py-4 rounded-full shadow-2xl hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex items-center gap-3 cursor-pointer border border-white/10"
      aria-label="Order Now"
    >
      <ShoppingBag className="w-5 h-5 text-anokhi-pink" />
      <span className="font-medium tracking-wide text-sm md:text-base">ORDER NOW</span>
    </motion.a>
  );
}
