export function Footer() {
  return (
    <footer className="bg-anokhi-purple text-white py-20 px-6 md:px-12 rounded-t-[40px] mt-24">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-2">
          <h2 className="font-display text-2xl font-semibold tracking-wide mb-4 flex items-center gap-2">
            ANOKHI ORIGINALS
          </h2>
          <p className="text-white/70 max-w-sm mb-6 font-light">
            Protecting Women.<br/>
            Growing Futures.
          </p>
          <div className="text-xl font-display italic text-anokhi-pink">
            One Cycle. One Plant.
          </div>
        </div>

        <div>
          <h3 className="font-medium text-lg mb-6">Quick Links</h3>
          <ul className="space-y-4 text-white/70">
            <li><a href="#knowledge" className="hover:text-white hover:underline transition-all">Knowledge Hub</a></li>
            <li><a href="#partner" className="hover:text-white hover:underline transition-all">Partner Program</a></li>
            <li><a href="#contact" className="hover:text-white hover:underline transition-all">Contact Us</a></li>
          </ul>
        </div>

        <div>
          <h3 className="font-medium text-lg mb-6">Legal</h3>
          <ul className="space-y-4 text-white/70">
            <li><a href="#" className="hover:text-white hover:underline transition-all">Privacy Policy</a></li>
            <li><a href="#" className="hover:text-white hover:underline transition-all">Terms of Service</a></li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/50">
        <p>&copy; {new Date().getFullYear()} ANOKHI ORIGINALS. All rights reserved.</p>
        <p>Built for the movement.</p>
      </div>
    </footer>
  );
}
