import { useState, useEffect } from 'react';
import { Menu, X, Leaf } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Mission', href: '#mission' },
    { name: 'Impact', href: '#impact' },
    { name: 'Stories', href: '#stories' },
    { name: 'Partner', href: '#partner' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ease-out border-b border-transparent ${
        isScrolled
          ? 'bg-white/80 backdrop-blur-md border-anokhi-purple/10 py-3 shadow-sm'
          : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <a href="#" className="flex items-center gap-2 group">
          <Leaf className="w-5 h-5 text-anokhi-green transition-transform group-hover:scale-110" />
          <span className="font-display font-semibold tracking-wide text-lg text-anokhi-purple">
            ANOKHI ORIGINALS
          </span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-sm font-medium text-anokhi-purple/70 hover:text-anokhi-purple transition-colors"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#partner"
            className="px-5 py-2.5 rounded-full bg-anokhi-purple text-white text-sm font-medium hover:bg-anokhi-purple/90 transition-all hover:scale-105 active:scale-95"
          >
            Join Movement
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden p-2 text-anokhi-purple"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full left-0 w-full bg-white shadow-xl py-4 flex flex-col md:hidden border-t border-anokhi-purple/10"
          >
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-6 py-4 text-anokhi-purple font-medium hover:bg-anokhi-pink/30 transition-colors"
              >
                {link.name}
              </a>
            ))}
            <div className="px-6 pt-4 pb-2">
              <a
                href="#partner"
                onClick={() => setMobileMenuOpen(false)}
                className="block text-center w-full py-3 rounded-full bg-anokhi-purple text-white font-medium shadow-md shadow-anokhi-purple/20"
              >
                Join Movement
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
