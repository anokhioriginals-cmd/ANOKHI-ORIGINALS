import { motion } from 'motion/react';
import { ShoppingBag, Mail, Sprout, Share2, Globe } from 'lucide-react';

export function Movement() {
  const steps = [
    { id: 1, title: 'Choose ANOKHI ORIGINALS', desc: 'Make the switch to premium protection.', icon: ShoppingBag },
    { id: 2, title: 'Receive Your Seed Card', desc: 'Every pack contains a biodegradable seed card.', icon: Mail },
    { id: 3, title: 'Plant It', desc: 'Give the seeds soil, water, and sunlight.', icon: Sprout },
    { id: 4, title: 'Share Your Story', desc: 'Upload a picture of your growing plant.', icon: Share2 },
    { id: 5, title: 'Inspire Others', desc: 'Join thousands of women growing futures.', icon: Globe },
  ];

  return (
    <section className="py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="max-w-2xl mb-20">
          <h2 className="text-4xl md:text-5xl font-display font-semibold text-anokhi-purple mb-6">
            How The Movement Works
          </h2>
          <p className="text-xl text-anokhi-purple/60">
            A simple, five-step journey from personal care to planetary impact.
          </p>
        </div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="hidden md:block absolute top-[60px] left-[60px] right-[60px] h-0.5 bg-anokhi-purple/10 border-dashed z-0" />

          <div className="grid grid-cols-1 md:grid-cols-5 gap-12 md:gap-6 relative z-10">
            {steps.map((step, idx) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2, duration: 0.6 }}
                className="flex flex-col items-center text-center relative"
              >
                <div className="w-[120px] h-[120px] rounded-full bg-white border border-anokhi-purple/10 shadow-xl shadow-anokhi-purple/5 flex items-center justify-center mb-8 relative group hover:-translate-y-2 transition-transform duration-300">
                  <div className="absolute -inset-2 rounded-full border border-anokhi-green/20 scale-90 opacity-0 group-hover:scale-100 group-hover:opacity-100 transition-all duration-500" />
                  <step.icon className="w-10 h-10 text-anokhi-green group-hover:text-anokhi-purple transition-colors duration-300" />
                  <div className="absolute top-0 right-0 w-8 h-8 rounded-full bg-anokhi-pink flex items-center justify-center text-anokhi-purple font-medium text-sm border-2 border-white shadow-sm">
                    {step.id}
                  </div>
                </div>
                
                <h3 className="font-display font-semibold text-xl text-anokhi-purple mb-3">
                  {step.title}
                </h3>
                <p className="text-anokhi-purple/60 leading-relaxed font-light">
                  {step.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
