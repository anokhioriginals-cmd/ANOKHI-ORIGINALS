import { useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Factory, HandHeart, School } from 'lucide-react';

export function Partnership() {
  const [formData, setFormData] = useState({
    category: 'NGO',
    name: '',
    organization: '',
    email: '',
    phone: '',
    message: ''
  });
  
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    
    try {
      const res = await fetch('/api/partner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        setStatus('success');
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  const categories = [
    { id: 'NGO', label: 'NGO Collaboration', icon: HandHeart },
    { id: 'School', label: 'School Campaign', icon: School },
    { id: 'Distributor', label: 'Distributor', icon: Factory },
  ];

  return (
    <section id="partner" className="py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="max-w-xl"
        >
          <h2 className="text-4xl md:text-5xl font-display font-semibold text-anokhi-purple mb-6">
            Building Impact Together
          </h2>
          <p className="text-xl text-anokhi-purple/60 font-light mb-12">
            Let's create impact together. Join hands with ANOKHI ORIGINALS to bring premium protection and environmental sustainability to your community.
          </p>

          <div className="space-y-8">
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-full bg-anokhi-green/10 flex items-center justify-center shrink-0">
                <School className="w-6 h-6 text-anokhi-green" />
              </div>
              <div>
                <h4 className="font-medium text-lg text-anokhi-purple mb-2">Schools & Colleges</h4>
                <p className="text-anokhi-purple/60 text-sm">Empower young women with hygiene education and sustainable habits.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-full bg-anokhi-pink flex items-center justify-center shrink-0">
                <HandHeart className="w-6 h-6 text-anokhi-purple" />
              </div>
              <div>
                <h4 className="font-medium text-lg text-anokhi-purple mb-2">NGOs & CSR</h4>
                <p className="text-anokhi-purple/60 text-sm">Distribute health, dignity, and a greener future in communities.</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
           initial={{ opacity: 0, y: 30 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           className="glass-card rounded-[40px] p-8 md:p-12 border border-anokhi-purple/10"
        >
          <h3 className="text-2xl font-display font-medium text-anokhi-purple mb-8">Become A Partner</h3>
          
          {status === 'success' ? (
            <div className="text-center py-12">
              <CheckCircle2 className="w-16 h-16 text-anokhi-green mx-auto mb-6" />
              <h4 className="text-xl font-display font-medium text-anokhi-purple mb-2">Application Received</h4>
              <p className="text-anokhi-purple/60">Thank you for reaching out. Our partnership team will contact you shortly.</p>
              <button 
                onClick={() => setStatus('idle')}
                className="mt-8 text-anokhi-green font-medium hover:underline"
              >
                Submit another request
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              <div className="grid grid-cols-3 gap-3 mb-6">
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setFormData({...formData, category: cat.id})}
                    className={`py-3 px-2 rounded-xl flex flex-col items-center gap-2 border transition-all text-xs sm:text-sm font-medium ${
                      formData.category === cat.id 
                      ? 'bg-anokhi-purple text-white border-anokhi-purple' 
                      : 'bg-white text-anokhi-purple/60 border-anokhi-purple/10 hover:border-anokhi-purple/30'
                    }`}
                  >
                    <cat.icon className="w-5 h-5" />
                    {cat.id}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="col-span-2 md:col-span-1">
                  <label className="block text-sm font-medium text-anokhi-purple/80 mb-2">Your Name</label>
                  <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-white border border-anokhi-purple/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-anokhi-green" />
                </div>
                <div className="col-span-2 md:col-span-1">
                  <label className="block text-sm font-medium text-anokhi-purple/80 mb-2">Organization</label>
                  <input required type="text" value={formData.organization} onChange={e => setFormData({...formData, organization: e.target.value})} className="w-full bg-white border border-anokhi-purple/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-anokhi-green" />
                </div>
                <div className="col-span-2 md:col-span-1">
                  <label className="block text-sm font-medium text-anokhi-purple/80 mb-2">Email Address</label>
                  <input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-white border border-anokhi-purple/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-anokhi-green" />
                </div>
                <div className="col-span-2 md:col-span-1">
                  <label className="block text-sm font-medium text-anokhi-purple/80 mb-2">Phone Number</label>
                  <input required type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full bg-white border border-anokhi-purple/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-anokhi-green" />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-anokhi-purple/80 mb-2">Message</label>
                  <textarea required rows={4} value={formData.message} onChange={e => setFormData({...formData, message: e.target.value})} className="w-full bg-white border border-anokhi-purple/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-anokhi-green resize-none"></textarea>
                </div>
              </div>

              {status === 'error' && (
                <p className="text-red-500 text-sm">Something went wrong. Please try again.</p>
              )}

              <button 
                type="submit" 
                disabled={status === 'submitting'}
                className="w-full bg-anokhi-green text-white py-4 rounded-xl font-medium hover:bg-anokhi-green/90 transition-colors shadow-lg shadow-anokhi-green/20 disabled:opacity-70 flex justify-center items-center"
              >
                {status === 'submitting' ? 'Submitting...' : 'Submit Request'}
              </button>
            </form>
          )}
        </motion.div>

      </div>
    </section>
  );
}
