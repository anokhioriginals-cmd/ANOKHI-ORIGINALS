import { motion } from 'motion/react';
import { ArrowRight, Sprout, Leaf } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center pt-24 overflow-hidden bg-gradient-to-b from-anokhi-pink/20 to-white">
      {/* Background Decor */}
      <div className="absolute inset-0 w-full h-full pointer-events-none overflow-hidden">
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 2, ease: "easeOut" }}
          className="absolute -top-[10%] -right-[10%] w-[50%] h-[50%] rounded-full bg-anokhi-green/5 blur-[120px]"
        />
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 2, ease: "easeOut", delay: 0.2 }}
          className="absolute top-[20%] -left-[10%] w-[40%] h-[40%] rounded-full bg-anokhi-purple/5 blur-[100px]"
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10 w-full grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-anokhi-green/20 bg-anokhi-green/5 text-anokhi-green font-medium text-sm mb-8">
            <Sprout className="w-4 h-4" />
            <span>One Cycle. One Plant.</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-semibold text-anokhi-purple leading-[1.1] mb-6 tracking-tight">
            Every Cycle Can Create <span className="text-anokhi-green block mt-2">Life Twice.</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-anokhi-purple/60 font-light mb-6">
            Once For You.<br/>
            Once For The Planet.
          </p>

          <p className="text-lg text-anokhi-purple/70 mb-10 max-w-lg leading-relaxed">
            ANOKHI ORIGINALS is building a future where menstrual care creates positive environmental impact. Every pack supports the global movement.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <a 
              href="#partner" 
              className="px-8 py-4 rounded-full bg-anokhi-green text-white font-medium hover:bg-anokhi-green/90 transition-all hover:scale-105 active:scale-95 shadow-lg shadow-anokhi-green/20 flex items-center gap-2 group w-full sm:w-auto justify-center"
            >
              JOIN THE MOVEMENT
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="#stories" 
              className="px-8 py-4 rounded-full bg-anokhi-purple/5 text-anokhi-purple font-medium hover:bg-anokhi-purple/10 transition-all w-full sm:w-auto justify-center text-center"
            >
              SHARE YOUR PLANT STORY
            </a>
          </div>
        </motion.div>

        {/* Hero Visual */}
        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, ease: "easeOut", delay: 0.3 }}
          className="relative lg:h-[600px] flex items-center justify-center"
        >
          <div className="relative w-full aspect-square max-w-md mx-auto">
            {/* Abstract visual representing a plant / seed card */}
            <div className="absolute inset-0 bg-gradient-to-tr from-anokhi-pink to-anokhi-purple/10 rounded-[40px] rotate-3 transform transition-transform hover:rotate-6 duration-700"></div>
            <div className="absolute inset-0 bg-white shadow-xl rounded-[40px] -rotate-3 overflow-hidden border border-black/5 flex flex-col items-center justify-center p-8 transform transition-transform hover:rotate-0 duration-700">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 1.5, ease: "backOut", delay: 0.6 }}
              >
                <div className="w-48 h-64 bg-anokhi-green/10 rounded-t-full rounded-b-2xl flex flex-col items-center justify-end pb-8 relative overflow-hidden">
                   {/* Plant growth abstract */}
                   <motion.div 
                     initial={{ height: "0%" }}
                     animate={{ height: "60%" }}
                     transition={{ duration: 2, ease: "easeOut", delay: 1 }}
                     className="w-2 bg-anokhi-green/40 rounded-t-full flex justify-center"
                   >
                     <motion.div 
                       initial={{ scale: 0 }}
                       animate={{ scale: 1 }}
                       transition={{ duration: 0.8, delay: 2.8 }}
                       className="absolute -top-6 w-16 h-16 origin-bottom"
                     >
                       <Leaf className="w-full h-full text-anokhi-green drop-shadow-md" />
                     </motion.div>
                   </motion.div>
                </div>
              </motion.div>
              <p className="mt-8 font-display font-medium text-anokhi-purple tracking-widest text-sm uppercase">The Seed Card</p>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
}
