import { useState } from 'react';
import { motion } from 'motion/react';
import { Upload, MapPin, Heart } from 'lucide-react';

export function StoryWall() {
  const [showForm, setShowForm] = useState(false);

  // Mocked stories for visual presentation
  const stories = [
    { id: 1, name: 'Priya M.', location: 'Mumbai', plant: 'Marigold', img: 'https://images.unsplash.com/photo-1599839619722-39751411ea63?w=500&q=80', likes: 124 },
    { id: 2, name: 'Ananya S.', location: 'Bangalore', plant: 'Tulsi', img: 'https://images.unsplash.com/photo-1628157771761-4191cbba205d?w=500&q=80', likes: 89 },
    { id: 3, name: 'Ritu K.', location: 'Delhi', plant: 'Sunflower', img: 'https://images.unsplash.com/photo-1597848212624-a19eb35e2651?w=500&q=80', likes: 256 },
    { id: 4, name: 'Sneha R.', location: 'Pune', plant: 'Aloe Vera', img: 'https://images.unsplash.com/photo-1616788556608-f463d13264f3?w=500&q=80', likes: 112 },
  ];

  return (
    <section id="stories" className="py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-display font-semibold text-anokhi-purple mb-6">
               Real Women.<br/>Real Plants.<br/>Real Impact.
            </h2>
            <p className="text-xl text-anokhi-purple/60 font-light">
              Explore the growing forest planted by the ANOKHI ORIGINALS community.
            </p>
          </div>
          <button 
            onClick={() => setShowForm(!showForm)}
            className="px-8 py-4 rounded-full bg-anokhi-purple text-white font-medium hover:bg-anokhi-purple/90 transition-all flex items-center gap-3 shrink-0"
          >
            <Upload className="w-5 h-5" />
            UPLOAD YOUR STORY
          </button>
        </div>

        {showForm && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mb-16 glass-card p-8 rounded-[32px] border border-anokhi-purple/10 max-w-2xl mx-auto"
          >
            <form onSubmit={(e) => { e.preventDefault(); alert("Image upload functionality requires storage backend."); }} className="space-y-6">
              <h3 className="text-2xl font-display font-semibold text-anokhi-purple">Share Your Plant</h3>
              <div className="grid grid-cols-2 gap-6">
                <input type="text" placeholder="Your Name" required className="col-span-2 md:col-span-1 w-full bg-white border border-black/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-anokhi-green" />
                <input type="text" placeholder="Location City" required className="col-span-2 md:col-span-1 w-full bg-white border border-black/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-anokhi-green" />
                <input type="text" placeholder="Plant Species" required className="col-span-2 w-full bg-white border border-black/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-anokhi-green" />
                
                <div className="col-span-2 border-2 border-dashed border-black/10 rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer hover:bg-black/5 transition-colors">
                  <Upload className="w-8 h-8 text-anokhi-purple/40 mb-2" />
                  <span className="text-anokhi-purple/60 text-sm">Click to upload photo</span>
                </div>
              </div>
              <button type="submit" className="w-full bg-anokhi-green text-white py-4 rounded-xl font-medium hover:bg-anokhi-green/90 transition-colors">
                Share With Community
              </button>
            </form>
          </motion.div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stories.map((story, idx) => (
            <motion.div
              key={story.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              className="group rounded-3xl overflow-hidden relative aspect-[4/5] bg-gray-100"
            >
              <img src={story.img} alt={story.plant} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80" />
              
              <div className="absolute bottom-0 left-0 w-full p-6 text-white flex flex-col gap-2">
                <div className="flex items-center gap-1.5 text-white/80 text-sm">
                  <MapPin className="w-4 h-4" /> {story.location}
                </div>
                <h3 className="font-display font-medium text-xl">{story.plant}</h3>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-sm text-white/80">by {story.name}</span>
                  <div className="flex items-center gap-1 text-sm bg-white/20 backdrop-blur-md px-3 py-1 rounded-full">
                    <Heart className="w-3 h-3" /> {story.likes}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
