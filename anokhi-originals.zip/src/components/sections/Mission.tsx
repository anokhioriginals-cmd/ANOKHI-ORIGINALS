import { motion } from 'motion/react';

export function Mission() {
  return (
    <section id="mission" className="py-32 px-6 md:px-12 bg-white flex items-center justify-center text-center">
      <div className="max-w-4xl mx-auto">
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-anokhi-green font-medium tracking-widest uppercase mb-8"
        >
          Our Mission
        </motion.p>
        
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-4xl md:text-6xl lg:text-7xl font-display font-semibold text-anokhi-purple mb-12 leading-tight"
        >
          One Cycle.<br/>
          <span className="italic font-light text-anokhi-green">One Plant.</span>
        </motion.h2>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="space-y-6 text-xl md:text-2xl text-anokhi-purple/70 font-light max-w-2xl mx-auto leading-relaxed"
        >
          <p>Millions of menstrual cycles happen every day.</p>
          <p className="font-medium text-anokhi-purple">What if every cycle could help grow something beautiful?</p>
          <p>
            ANOKHI ORIGINALS was created to connect women's health with environmental action. 
          </p>
          <p className="pt-8 text-anokhi-purple/50 text-lg">
            One product. One action. One plant at a time.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
