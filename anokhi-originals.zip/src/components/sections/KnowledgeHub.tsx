import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function KnowledgeHub() {
  const articles = [
    { title: "Understanding PCOS and Menstrual Health", category: "Women's Health", date: "Oct 12, 2025" },
    { title: "The Environmental Impact of Traditional Pads", category: "Sustainability", date: "Sep 28, 2025" },
    { title: "A Beginner's Guide to Planting Your Seed Card", category: "Planting Guides", date: "Sep 15, 2025" },
  ];

  return (
    <section id="knowledge" className="py-32 px-6 md:px-12 bg-anokhi-pink/20">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-xl">
             <h2 className="text-4xl md:text-5xl font-display font-semibold text-anokhi-purple mb-6">
              Knowledge Hub
            </h2>
            <p className="text-xl text-anokhi-purple/60 font-light">
              Resources, education, and insights on women's health and environmental sustainability.
            </p>
          </div>
          <button className="text-anokhi-purple font-medium hover:text-anokhi-green transition-colors flex items-center gap-2 group">
            View All Articles <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {articles.map((article, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-[32px] p-8 shadow-sm border border-anokhi-purple/5 group cursor-pointer hover:shadow-xl hover:shadow-anokhi-purple/5 transition-all duration-300"
            >
              <div className="text-anokhi-green text-sm font-medium uppercase tracking-wider mb-4">
                {article.category}
              </div>
              <h3 className="text-2xl font-display font-medium text-anokhi-purple mb-12 group-hover:text-anokhi-green transition-colors leading-snug">
                {article.title}
              </h3>
              <div className="flex items-center justify-between text-anokhi-purple/40 text-sm">
                <span>{article.date}</span>
                <div className="w-8 h-8 rounded-full bg-anokhi-pink/50 flex items-center justify-center group-hover:bg-anokhi-green group-hover:text-white transition-colors">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
