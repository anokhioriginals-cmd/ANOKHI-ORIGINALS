import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Users, Sprout, Building, GraduationCap, MapPin, Heart } from 'lucide-react';

export function ImpactDashboard() {
  const [metrics, setMetrics] = useState({
    plantsShared: 0,
    womenReached: 0,
    schoolsConnected: 0,
    ngoPartnerships: 0,
    communitiesImpacted: 0,
    plantStories: 0,
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/impact')
      .then(res => res.json())
      .then(data => {
        setMetrics(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to fetch impact metrics:', err);
        // Fallback data
        setMetrics({
          plantsShared: 14500,
          womenReached: 8200,
          schoolsConnected: 120,
          ngoPartnerships: 45,
          communitiesImpacted: 8,
          plantStories: 3200,
        });
        setLoading(false);
      });
  }, []);

  const statCards = [
    { label: 'Plants Shared', value: metrics.plantsShared, icon: Sprout, color: 'text-anokhi-green', bg: 'bg-anokhi-green/10' },
    { label: 'Women Reached', value: metrics.womenReached, icon: Users, color: 'text-anokhi-purple', bg: 'bg-anokhi-purple/10' },
    { label: 'Schools Connected', value: metrics.schoolsConnected, icon: GraduationCap, color: 'text-blue-600', bg: 'bg-blue-600/10' },
    { label: 'NGO Partnerships', value: metrics.ngoPartnerships, icon: Building, color: 'text-orange-600', bg: 'bg-orange-600/10' },
    { label: 'Communities Impacted', value: metrics.communitiesImpacted, icon: MapPin, color: 'text-rose-600', bg: 'bg-rose-600/10' },
    { label: 'Plant Stories', value: metrics.plantStories, icon: Heart, color: 'text-pink-600', bg: 'bg-pink-600/10' },
  ];

  // Helper for simple counter animation formatting
  const formatNumber = (num: number) => new Intl.NumberFormat('en-IN').format(num);

  return (
    <section id="impact" className="py-32 px-6 md:px-12 bg-anokhi-purple/5">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display font-semibold text-anokhi-purple mb-4"
          >
            Growing Together
          </motion.h2>
          <p className="text-xl text-anokhi-purple/60 max-w-2xl mx-auto">
            Real-time impact powered by our community.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-8">
          {statCards.map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
              className="glass-card rounded-[32px] p-6 text-center hover:-translate-y-2 transition-transform duration-300"
            >
              <div className={`w-14 h-14 mx-auto rounded-full ${stat.bg} ${stat.color} flex items-center justify-center mb-6`}>
                <stat.icon className="w-7 h-7" />
              </div>
              <div className="text-3xl md:text-4xl font-display font-bold text-anokhi-purple mb-2">
                {loading ? '...' : formatNumber(stat.value)}
                {stat.label !== 'Communities Impacted' && <span className="text-anokhi-green">+</span>}
              </div>
              <div className="text-sm md:text-base font-medium text-anokhi-purple/60">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
