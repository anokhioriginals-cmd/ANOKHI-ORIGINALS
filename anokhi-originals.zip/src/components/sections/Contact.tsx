import { motion } from 'motion/react';
import { Phone, Mail, MapPin, Instagram, Youtube, Twitter } from 'lucide-react';

export function Contact() {
  return (
    <section id="contact" className="py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-display font-semibold text-anokhi-purple mb-6">
              Get in Touch
            </h2>
            <p className="text-xl text-anokhi-purple/60 font-light mb-12">
              Have questions about our products, the movement, or partnerships? We'd love to hear from you.
            </p>

            <div className="space-y-8">
              <a href="tel:+919456674174" className="flex items-center gap-6 group hover:-translate-y-1 transition-transform">
                <div className="w-14 h-14 rounded-full bg-anokhi-purple/5 flex items-center justify-center shrink-0 group-hover:bg-anokhi-green/10 group-hover:text-anokhi-green transition-colors">
                  <Phone className="w-6 h-6 text-anokhi-purple group-hover:text-anokhi-green transition-colors" />
                </div>
                <div>
                  <h4 className="font-medium text-anokhi-purple/60 text-sm mb-1 uppercase tracking-wider">Phone</h4>
                  <p className="text-2xl font-display text-anokhi-purple">+91 9456674174</p>
                </div>
              </a>
              
              <a href="mailto:info@ogwomen.com" className="flex items-center gap-6 group hover:-translate-y-1 transition-transform">
                <div className="w-14 h-14 rounded-full bg-anokhi-purple/5 flex items-center justify-center shrink-0 group-hover:bg-anokhi-green/10 transition-colors">
                  <Mail className="w-6 h-6 text-anokhi-purple group-hover:text-anokhi-green transition-colors" />
                </div>
                <div>
                  <h4 className="font-medium text-anokhi-purple/60 text-sm mb-1 uppercase tracking-wider">Email</h4>
                  <p className="text-xl md:text-2xl font-display text-anokhi-purple">info@ogwomen.com</p>
                </div>
              </a>
            </div>

            <div className="mt-16">
              <h4 className="font-medium text-anokhi-purple/60 text-sm mb-6 uppercase tracking-wider">Follow The Movement</h4>
              <div className="flex gap-4">
                <a href="#" className="w-12 h-12 rounded-full border border-anokhi-purple/10 flex items-center justify-center hover:border-anokhi-green hover:text-anokhi-green transition-colors text-anokhi-purple">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="#" className="w-12 h-12 rounded-full border border-anokhi-purple/10 flex items-center justify-center hover:border-anokhi-green hover:text-anokhi-green transition-colors text-anokhi-purple">
                  <Youtube className="w-5 h-5" />
                </a>
                <a href="#" className="w-12 h-12 rounded-full border border-anokhi-purple/10 flex items-center justify-center hover:border-anokhi-green hover:text-anokhi-green transition-colors text-anokhi-purple">
                  <Twitter className="w-5 h-5" />
                </a>
              </div>
            </div>
          </motion.div>

          <motion.div
             initial={{ opacity: 0, scale: 0.95 }}
             whileInView={{ opacity: 1, scale: 1 }}
             viewport={{ once: true }}
             className="w-full h-[400px] lg:h-auto rounded-[40px] overflow-hidden bg-gray-100 border border-anokhi-purple/10"
          >
            {/* Simple Map Placeholder (Google Maps Integration point) */}
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14008.114827184245!2d77.20902120000002!3d28.6139391!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5b347eb62d%3A0x37205b715389640!2sNew%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" 
              width="100%" 
              height="100%" 
              style={{ border: 0, filter: 'grayscale(1) contrast(1.2)' }} 
              allowFullScreen 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </motion.div>
          
        </div>
      </div>
    </section>
  );
}
