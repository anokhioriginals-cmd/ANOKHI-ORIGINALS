import { motion } from 'motion/react';

export function Vision() {
  return (
    <section className="py-40 px-6 md:px-12 bg-anokhi-purple text-white text-center relative overflow-hidden">
      
      {/* Background Decor */}
      <div className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-[400px] bg-gradient-to-b from-anokhi-green to-transparent blur-[100px] rounded-full" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-anokhi-green font-medium tracking-widest uppercase mb-12"
        >
          Our Vision
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="space-y-6 text-3xl md:text-5xl lg:text-6xl font-display font-light leading-tight"
        >
          <p>To build India's most trusted<br/>women's hygiene movement.</p>
          <p className="text-white/40 pt-12 text-2xl md:text-4xl">Not just a product. <span className="text-white">A movement.</span></p>
          <p className="text-white/40 text-2xl md:text-4xl">Not just protection. <span className="text-white">A purpose.</span></p>
          <p className="text-white/40 text-2xl md:text-4xl">Not just a cycle. <span className="text-anokhi-green italic">A future.</span></p>
        </motion.div>
      </div>
    </section>
  );
}
