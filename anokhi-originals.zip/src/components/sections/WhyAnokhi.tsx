import { motion } from 'motion/react';
import { ShieldCheck, Leaf, Users, Target } from 'lucide-react';

export function WhyAnokhi() {
  const features = [
    { title: "Premium Protection", desc: "Advanced absorption core with ultra-soft top layer for maximum comfort.", icon: ShieldCheck },
    { title: "Women First", desc: "Designed to respect a woman's dignity, health, and hygiene above all else.", icon: Users },
    { title: "Sustainability Driven", desc: "From packaging to the seed card, every element is designed with the earth in mind.", icon: Leaf },
    { title: "Purpose Led", desc: "We measure our success not just by sales, but by plants grown and lives touched.", icon: Target },
  ];

  return (
    <section className="py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display font-semibold text-anokhi-purple mb-6"
          >
            Why ANOKHI ORIGINALS
          </motion.h2>
          <p className="text-xl text-anokhi-purple/60 max-w-2xl mx-auto font-light">
            We are not just a sanitary pad company. We are a standard of care.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
              className="p-8 rounded-[32px] border border-anokhi-purple/10 hover:border-anokhi-purple/30 bg-gradient-to-b from-white to-anokhi-pink/5 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-full bg-anokhi-purple/5 flex items-center justify-center mb-8">
                <feature.icon className="w-7 h-7 text-anokhi-purple" />
              </div>
              <h3 className="text-xl font-display font-semibold text-anokhi-purple mb-4">
                {feature.title}
              </h3>
              <p className="text-anokhi-purple/60 leading-relaxed font-light">
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
