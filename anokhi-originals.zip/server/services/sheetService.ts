import { GoogleSpreadsheet } from 'google-spreadsheet';
import { JWT } from 'google-auth-library';

export class SheetService {
  private doc: GoogleSpreadsheet | null = null;
  private initialized = false;

  private async init() {
    if (this.initialized) return;

    const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
    const privateKey = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n');
    const sheetId = process.env.GOOGLE_SHEET_ID;

    if (!email || !privateKey || !sheetId) {
      console.warn('Google Sheets configuration missing. Service will be mocked.');
      this.initialized = true;
      return;
    }

    try {
      const auth = new JWT({
        email: email,
        key: privateKey,
        scopes: ['https://www.googleapis.com/auth/spreadsheets'],
      });

      this.doc = new GoogleSpreadsheet(sheetId, auth);
      await this.doc.loadInfo();
      this.initialized = true;
    } catch (error) {
      console.error('Failed to initialize Google Spreadsheet:', error);
    }
  }

  async getImpactMetrics() {
    await this.init();

    if (!this.doc) {
      // Mocked data
      return {
        plantsShared: 14500,
        womenReached: 8200,
        schoolsConnected: 120,
        ngoPartnerships: 45,
        communitiesImpacted: 8,
        plantStories: 3200,
        isPlaceholder: true,
      };
    }

    try {
      const sheet = this.doc.sheetsByTitle['ImpactMetrics'] || this.doc.sheetsByIndex[0];
      if (!sheet) {
         throw new Error('ImpactMetrics sheet not found');
      }

      await sheet.loadCells('A2:B7'); // If they are in the first few rows
      // Read data dynamically or via rows depending on the structured format in 'ImpactMetrics'
      // Assuming straightforward row-based label/value configuration
      const rows = await sheet.getRows();
      const metrics: any = { isPlaceholder: false };

      rows.forEach(row => {
        // google-spreadsheet v4 gets data via row.get('ColumnName') or row.get(0)
        // If it's a simple key value, we assume Headers: Metric | Value
        // Since it's dynamic, let's just attempt to read first two columns
        const label = row.get('Metric') || row._rawData[0];
        const value = parseInt(row.get('Value') || row._rawData[1] || '0', 10);
        
        switch(label) {
          case 'Plants Shared': metrics.plantsShared = value; break;
          case 'Women Reached': metrics.womenReached = value; break;
          case 'Schools Connected': metrics.schoolsConnected = value; break;
          case 'NGO Partnerships': metrics.ngoPartnerships = value; break;
          case 'Communities Impacted': metrics.communitiesImpacted = value; break;
          case 'Plant Stories': metrics.plantStories = value; break;
        }
      });

      return {
        plantsShared: metrics.plantsShared || 14500,
        womenReached: metrics.womenReached || 8200,
        schoolsConnected: metrics.schoolsConnected || 120,
        ngoPartnerships: metrics.ngoPartnerships || 45,
        communitiesImpacted: metrics.communitiesImpacted || 8,
        plantStories: metrics.plantStories || 3200,
        isPlaceholder: false
      };
    } catch (error) {
      console.error('Error reading from ImpactMetrics:', error);
      throw error;
    }
  }

  async submitPartnerForm(data: any) {
    await this.init();

    if (!this.doc) {
      console.log('Partner form submitted (mock):', data);
      return { success: true, mocked: true };
    }

    try {
      // Find or create the PartnerSubmissions sheet
      let sheet = this.doc.sheetsByTitle['PartnerSubmissions'];
      if (!sheet) {
        sheet = await this.doc.addSheet({ headerValues: ['Date', 'Category', 'Name', 'Organization', 'Email', 'Phone', 'Message'], title: 'PartnerSubmissions' });
      }

      await sheet.addRow({
        Date: new Date().toISOString(),
        Category: data.category,
        Name: data.name,
        Organization: data.organization,
        Email: data.email,
        Phone: data.phone,
        Message: data.message
      });

      return { success: true, mocked: false };
    } catch (error) {
      console.error('Error writing to PartnerSubmissions:', error);
      throw error;
    }
  }
}

export const sheetService = new SheetService();
