import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { sheetService } from './server/services/sheetService';

const app = express();
const PORT = 3000;

app.use(express.json());

// API: Get Impact Dashboard Metrics
app.get('/api/impact', async (req, res) => {
  try {
    const metrics = await sheetService.getImpactMetrics();
    res.json(metrics);
  } catch (error: any) {
    res.status(500).json({ error: 'Failed to fetch impact metrics' });
  }
});

// API: Submit Partner Form
app.post('/api/partner', async (req, res) => {
  try {
    const result = await sheetService.submitPartnerForm(req.body);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: 'Failed to submit partner form' });
  }
});

// API: Submit Plant Story (mock endpoint, since file uploads require a storage bucket)
// The actual implementation would use Multer + Cloud Storage
app.post('/api/story', async (req, res) => {
  // In a full implementation, you would handle multipart/form-data here,
  // upload the image to a storage bucket, and append the URL to a Google Sheet.
  console.log('Story submitted:', req.body);
  await new Promise(r => setTimeout(r, 1000)); // simulate latency
  res.json({ success: true });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
